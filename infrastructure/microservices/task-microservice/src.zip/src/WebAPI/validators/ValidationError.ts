export interface ValidationError {
    isValid: boolean;
    message?: string;
}