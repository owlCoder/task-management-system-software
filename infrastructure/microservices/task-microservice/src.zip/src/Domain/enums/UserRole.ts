export enum UserRole {
    SYSTEM_ADMIN = "SysAdmin",
    ADMIN = "Admin",
    PROJECT_MANAGER = "Project Manager",
    ANIMATION_WORKER = "Animation Worker",
    AUDIO_MUSIC_STAGIST = "Audio & Music Stagist" 
}