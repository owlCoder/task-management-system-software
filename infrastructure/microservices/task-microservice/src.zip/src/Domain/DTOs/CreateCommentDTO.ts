export interface CreateCommentDTO {
    user_id: number;
    comment: string;
}
